var structdirp__api__version__t =
[
    [ "api", "structdirp__api__version__t.html#a76a1ef1a4d3d9bd3e70783051f22a6d3", null ],
    [ "magic", "structdirp__api__version__t.html#a5e6c32d732993521cc8ba4669f82ced6", null ]
];