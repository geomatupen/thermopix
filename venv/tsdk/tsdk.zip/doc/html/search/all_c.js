var searchData=
[
  ['red_117',['red',['../structdirp__isp__pseudo__color__lut__t.html#afabc763345b8c8242356f8e93ebac8de',1,'dirp_isp_pseudo_color_lut_t']]],
  ['reflection_118',['reflection',['../structdirp__measurement__params__t.html#adfc4a7d81f395457c9111e79fdba8e51',1,'dirp_measurement_params_t::reflection()'],['../structdirp__measurement__params__range__t.html#a0d945903f35ae810bb9439f1e519f172',1,'dirp_measurement_params_range_t::reflection()']]],
  ['rjpeg_119',['rjpeg',['../structdirp__rjpeg__version__t.html#ab4e0e05c22a71b671c27dce34256ad61',1,'dirp_rjpeg_version_t']]]
];
