var searchData=
[
  ['destroy_172',['destroy',['../structdirp__api__wrapper__t.html#a5b10ce8fe656a4fe7568a9463d6fb00d',1,'dirp_api_wrapper_t']]],
  ['distance_173',['distance',['../structdirp__measurement__params__t.html#a06f14a9abd47b91465f895d5259cdc1b',1,'dirp_measurement_params_t::distance()'],['../structdirp__measurement__params__range__t.html#ab801c7d0a04d2a9691e7258bb259b506',1,'dirp_measurement_params_range_t::distance()']]]
];
