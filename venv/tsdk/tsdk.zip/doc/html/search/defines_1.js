var searchData=
[
  ['dirp_5fpseudo_5fcolor_5flut_5fdepth_252',['DIRP_PSEUDO_COLOR_LUT_DEPTH',['../dirp__api_8h.html#a98e0e666b4aa6dfd807432057cfc12fb',1,'dirp_api.h']]],
  ['dllexport_253',['dllexport',['../dirp__api_8h.html#af241d00f78195ece6ef34d97bb5c48f3',1,'dirp_api.h']]]
];
