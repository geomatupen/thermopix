var searchData=
[
  ['get_5fcolor_5fbar_92',['get_color_bar',['../structdirp__api__wrapper__t.html#aa166cf6cb11ff938d474010d984b83d4',1,'dirp_api_wrapper_t']]],
  ['get_5fcolor_5fbar_5fadaptive_5fparams_93',['get_color_bar_adaptive_params',['../structdirp__api__wrapper__t.html#afdf976e28b5777b1b49bfb70eb3928b4',1,'dirp_api_wrapper_t']]],
  ['get_5fenhancement_5fparams_94',['get_enhancement_params',['../structdirp__api__wrapper__t.html#ac9407cc4628a6871c4edc8805e96d286',1,'dirp_api_wrapper_t']]],
  ['get_5fisotherm_95',['get_isotherm',['../structdirp__api__wrapper__t.html#a0ce7391be635748246ba55643c7010a6',1,'dirp_api_wrapper_t']]],
  ['get_5fmeasurement_5fparams_96',['get_measurement_params',['../structdirp__api__wrapper__t.html#a3c0facc1d285a940e8881904c9fc43d9',1,'dirp_api_wrapper_t']]],
  ['get_5fmeasurement_5fparams_5frange_97',['get_measurement_params_range',['../structdirp__api__wrapper__t.html#a507c6e41e62fd80fa7f8a6acd9e2d256',1,'dirp_api_wrapper_t']]],
  ['get_5foriginal_5fraw_98',['get_original_raw',['../structdirp__api__wrapper__t.html#a0a011013fdae62b4bf5c91d497c1f847',1,'dirp_api_wrapper_t']]],
  ['get_5fpseudo_5fcolor_99',['get_pseudo_color',['../structdirp__api__wrapper__t.html#a84b39cfcff773fca34c5a81173344ef9',1,'dirp_api_wrapper_t']]],
  ['get_5fpseudo_5fcolor_5flut_100',['get_pseudo_color_lut',['../structdirp__api__wrapper__t.html#a7076701aed2b7cbf9aedad79f747bc22',1,'dirp_api_wrapper_t']]],
  ['get_5frjpeg_5fresolution_101',['get_rjpeg_resolution',['../structdirp__api__wrapper__t.html#a80c5309b85371a642a9d790a67819f0f',1,'dirp_api_wrapper_t']]],
  ['get_5frjpeg_5fversion_102',['get_rjpeg_version',['../structdirp__api__wrapper__t.html#abbb9a09d9c1a642cd7d615c68eb1743a',1,'dirp_api_wrapper_t']]],
  ['green_103',['green',['../structdirp__isp__pseudo__color__lut__t.html#af864d95f7681111a689547dcd871aab1',1,'dirp_isp_pseudo_color_lut_t']]]
];
