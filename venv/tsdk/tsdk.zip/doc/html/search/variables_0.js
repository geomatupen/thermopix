var searchData=
[
  ['ambient_5ftemp_166',['ambient_temp',['../structdirp__measurement__params__t.html#a263a7902eccf2c8f2716d4b9a817adfb',1,'dirp_measurement_params_t::ambient_temp()'],['../structdirp__measurement__params__range__t.html#a6f039ba7de6cfea1663e02e0dcd66a37',1,'dirp_measurement_params_range_t::ambient_temp()']]],
  ['api_167',['api',['../structdirp__api__version__t.html#a76a1ef1a4d3d9bd3e70783051f22a6d3',1,'dirp_api_version_t']]]
];
