var searchData=
[
  ['create_5ffrom_5frjpeg_6',['create_from_rjpeg',['../structdirp__api__wrapper__t.html#a6005edd791dc2372f001ccd057b9110e',1,'dirp_api_wrapper_t']]],
  ['curve_7',['curve',['../structdirp__rjpeg__version__t.html#a3e4868b09d98673c2fb4abbdb2cc352c',1,'dirp_rjpeg_version_t']]]
];
