var searchData=
[
  ['func_5fdirp_5fvendor_5fget_5fapi_91',['func_dirp_vendor_get_api',['../dirp__wrapper_8h.html#a7ea0bf19791cc36a3a83c74160db2fdb',1,'dirp_wrapper.h']]]
];
