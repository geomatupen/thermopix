var searchData=
[
  ['dirp_5fhandle_211',['DIRP_HANDLE',['../dirp__api_8h.html#afbb5c92b91edcf8ec72e83e253d1d247',1,'dirp_api.h']]],
  ['dirpv_5fhandle_212',['DIRPV_HANDLE',['../dirp__wrapper_8h.html#a37f14d6e5f30e04f94950d57ca115d62',1,'dirp_wrapper.h']]]
];
