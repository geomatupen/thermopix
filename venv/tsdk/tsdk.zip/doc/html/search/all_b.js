var searchData=
[
  ['process_115',['process',['../structdirp__api__wrapper__t.html#ac8cd082f8e6a78cbd87a2da317a41c81',1,'dirp_api_wrapper_t']]],
  ['process_5fstrech_116',['process_strech',['../structdirp__api__wrapper__t.html#a4600b3a1145cba126c3220a676eb4793',1,'dirp_api_wrapper_t']]]
];
