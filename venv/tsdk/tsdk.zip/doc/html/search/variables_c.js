var searchData=
[
  ['width_210',['width',['../structdirp__resolution__t.html#a395d15e7c2b09961c1bfd1da6179b64c',1,'dirp_resolution_t']]]
];
