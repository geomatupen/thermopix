var searchData=
[
  ['blue_4',['blue',['../structdirp__isp__pseudo__color__lut__t.html#a7a6d8b530979feae4d4bd07022238406',1,'dirp_isp_pseudo_color_lut_t']]],
  ['brightness_5',['brightness',['../structdirp__enhancement__params__t.html#a1c3a91a00bb8fad385be081f90e8fd2a',1,'dirp_enhancement_params_t']]]
];
