var searchData=
[
  ['set_5fcolor_5fbar_120',['set_color_bar',['../structdirp__api__wrapper__t.html#ab68ad79a113da5998fd099f49c85697d',1,'dirp_api_wrapper_t']]],
  ['set_5fenhancement_5fparams_121',['set_enhancement_params',['../structdirp__api__wrapper__t.html#a77544bba5e71436930950b91942c79ae',1,'dirp_api_wrapper_t']]],
  ['set_5fisotherm_122',['set_isotherm',['../structdirp__api__wrapper__t.html#a4fcc94b825ef43ddbcd57f3c26ad2426',1,'dirp_api_wrapper_t']]],
  ['set_5fmeasurement_5fparams_123',['set_measurement_params',['../structdirp__api__wrapper__t.html#abce31b1e126e53cb9821868c34fe31bd',1,'dirp_api_wrapper_t']]],
  ['set_5fpseudo_5fcolor_124',['set_pseudo_color',['../structdirp__api__wrapper__t.html#af1042caddabd0c9f4310ddcc1de16fb6',1,'dirp_api_wrapper_t']]],
  ['set_5fverbose_5flevel_125',['set_verbose_level',['../structdirp__api__wrapper__t.html#a240224033575055d5fd7f32fad98f14d',1,'dirp_api_wrapper_t']]]
];
