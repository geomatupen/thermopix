var structdirp__enhancement__params__t =
[
    [ "brightness", "structdirp__enhancement__params__t.html#a1c3a91a00bb8fad385be081f90e8fd2a", null ]
];