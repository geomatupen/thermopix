var structdirp__rjpeg__version__t =
[
    [ "curve", "structdirp__rjpeg__version__t.html#a3e4868b09d98673c2fb4abbdb2cc352c", null ],
    [ "header", "structdirp__rjpeg__version__t.html#abb4e7d30bf6f78c55f2118cd97a9ae24", null ],
    [ "rjpeg", "structdirp__rjpeg__version__t.html#ab4e0e05c22a71b671c27dce34256ad61", null ]
];