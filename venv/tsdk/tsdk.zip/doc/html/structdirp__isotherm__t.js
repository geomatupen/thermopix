var structdirp__isotherm__t =
[
    [ "enable", "structdirp__isotherm__t.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "high", "structdirp__isotherm__t.html#aad3745a166c82f18c12c48d8763cbb1e", null ],
    [ "low", "structdirp__isotherm__t.html#ab56f475c4370b93559ff9c7cf5e0fa91", null ]
];