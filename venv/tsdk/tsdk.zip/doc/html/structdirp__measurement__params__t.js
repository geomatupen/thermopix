var structdirp__measurement__params__t =
[
    [ "ambient_temp", "structdirp__measurement__params__t.html#a263a7902eccf2c8f2716d4b9a817adfb", null ],
    [ "distance", "structdirp__measurement__params__t.html#a06f14a9abd47b91465f895d5259cdc1b", null ],
    [ "emissivity", "structdirp__measurement__params__t.html#a8c5ceadb9fdb54e5f940d669f90843c0", null ],
    [ "humidity", "structdirp__measurement__params__t.html#a6a87b2b0cff24d38b367ccd34843a206", null ],
    [ "reflection", "structdirp__measurement__params__t.html#adfc4a7d81f395457c9111e79fdba8e51", null ]
];