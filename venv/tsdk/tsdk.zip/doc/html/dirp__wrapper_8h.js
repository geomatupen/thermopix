var dirp__wrapper_8h =
[
    [ "dirp_api_wrapper_t", "structdirp__api__wrapper__t.html", "structdirp__api__wrapper__t" ],
    [ "_DIRP_WRAPPER_H_", "dirp__wrapper_8h.html#a8f60ee44fe50bea0b11eba61550be84d", null ],
    [ "DIRPV_HANDLE", "dirp__wrapper_8h.html#a37f14d6e5f30e04f94950d57ca115d62", null ],
    [ "func_dirp_vendor_get_api", "dirp__wrapper_8h.html#a7ea0bf19791cc36a3a83c74160db2fdb", null ],
    [ "dirp_vendor_get_api", "dirp__wrapper_8h.html#a14d0d0028832428fb90036c0dd058543", null ]
];