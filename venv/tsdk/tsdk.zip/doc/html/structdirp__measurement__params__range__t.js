var structdirp__measurement__params__range__t =
[
    [ "ambient_temp", "structdirp__measurement__params__range__t.html#a6f039ba7de6cfea1663e02e0dcd66a37", null ],
    [ "distance", "structdirp__measurement__params__range__t.html#ab801c7d0a04d2a9691e7258bb259b506", null ],
    [ "emissivity", "structdirp__measurement__params__range__t.html#adc57ddb5f9cee65d9fcb4432e8e47c89", null ],
    [ "humidity", "structdirp__measurement__params__range__t.html#acebac19159cd418eed9d5c80202f13b2", null ],
    [ "max", "structdirp__measurement__params__range__t.html#a306b5ca364bf842a8ff5bbfc0b4d4a4b", null ],
    [ "min", "structdirp__measurement__params__range__t.html#ad2e88d75f808e6d4e78d48bceb10c336", null ],
    [ "reflection", "structdirp__measurement__params__range__t.html#a0d945903f35ae810bb9439f1e519f172", null ]
];