var files_dup =
[
    [ "dirp_api.h", "dirp__api_8h.html", "dirp__api_8h" ],
    [ "dirp_wrapper.h", "dirp__wrapper_8h.html", "dirp__wrapper_8h" ]
];