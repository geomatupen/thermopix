var annotated_dup =
[
    [ "dirp_api_version_t", "structdirp__api__version__t.html", "structdirp__api__version__t" ],
    [ "dirp_api_wrapper_t", "structdirp__api__wrapper__t.html", "structdirp__api__wrapper__t" ],
    [ "dirp_color_bar_t", "structdirp__color__bar__t.html", "structdirp__color__bar__t" ],
    [ "dirp_enhancement_params_t", "structdirp__enhancement__params__t.html", "structdirp__enhancement__params__t" ],
    [ "dirp_isotherm_t", "structdirp__isotherm__t.html", "structdirp__isotherm__t" ],
    [ "dirp_isp_pseudo_color_lut_t", "structdirp__isp__pseudo__color__lut__t.html", "structdirp__isp__pseudo__color__lut__t" ],
    [ "dirp_measurement_params_range_t", "structdirp__measurement__params__range__t.html", "structdirp__measurement__params__range__t" ],
    [ "dirp_measurement_params_t", "structdirp__measurement__params__t.html", "structdirp__measurement__params__t" ],
    [ "dirp_resolution_t", "structdirp__resolution__t.html", "structdirp__resolution__t" ],
    [ "dirp_rjpeg_version_t", "structdirp__rjpeg__version__t.html", "structdirp__rjpeg__version__t" ]
];