var structdirp__color__bar__t =
[
    [ "high", "structdirp__color__bar__t.html#aad3745a166c82f18c12c48d8763cbb1e", null ],
    [ "low", "structdirp__color__bar__t.html#ab56f475c4370b93559ff9c7cf5e0fa91", null ],
    [ "manual_enable", "structdirp__color__bar__t.html#a8c76543a8e2f111661f7f1681317e63b", null ]
];