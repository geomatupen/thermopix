var structdirp__isp__pseudo__color__lut__t =
[
    [ "blue", "structdirp__isp__pseudo__color__lut__t.html#a7a6d8b530979feae4d4bd07022238406", null ],
    [ "green", "structdirp__isp__pseudo__color__lut__t.html#af864d95f7681111a689547dcd871aab1", null ],
    [ "red", "structdirp__isp__pseudo__color__lut__t.html#afabc763345b8c8242356f8e93ebac8de", null ]
];