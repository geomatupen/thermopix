var structdirp__resolution__t =
[
    [ "height", "structdirp__resolution__t.html#a5d8006e753a3e76ff637a4e092bbed71", null ],
    [ "width", "structdirp__resolution__t.html#a395d15e7c2b09961c1bfd1da6179b64c", null ]
];